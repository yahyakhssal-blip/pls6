Dirham Bot — npm install ثم ضع token و clientId في config.json ثم npm start.
فعّل Message Content Intent و Server Members Intent.